<?php

require 'vendor/autoload.php';
require 'TestCase.php';

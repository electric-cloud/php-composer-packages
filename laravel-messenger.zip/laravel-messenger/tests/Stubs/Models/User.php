<?php

namespace Cmgmyr\Messenger\Test\Stubs\Models;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
}

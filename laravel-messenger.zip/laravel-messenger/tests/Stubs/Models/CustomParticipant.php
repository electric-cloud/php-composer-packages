<?php

namespace Cmgmyr\Messenger\Test\Stubs\Models;

use Cmgmyr\Messenger\Models\Participant;

class CustomParticipant extends Participant
{
    protected $table = 'custom_participants';
}

<?php

namespace Cmgmyr\Messenger\Test\Stubs\Models;

use Cmgmyr\Messenger\Models\Thread;

class CustomThread extends Thread
{
    protected $table = 'custom_threads';
}
